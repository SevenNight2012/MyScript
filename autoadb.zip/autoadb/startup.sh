#!/usr/bin/env bash
autoadb scrcpy -s '{}'
